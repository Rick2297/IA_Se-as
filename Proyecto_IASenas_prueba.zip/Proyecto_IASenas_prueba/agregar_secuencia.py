import pandas as pd
import numpy as np

df = pd.read_csv('landmarks_dataset_secuencias.csv')
etiquetas_unicas = df['label'].unique()
print(f"✅ Etiquetas únicas en el dataset: {etiquetas_unicas}")

np.save('landmarks_labels.npy', etiquetas_unicas)
print("✅ Archivo landmarks_labels.npy actualizado con todas las etiquetas.")
