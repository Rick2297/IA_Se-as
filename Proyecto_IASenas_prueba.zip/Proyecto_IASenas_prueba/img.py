import cv2
import numpy as np
import mediapipe as mp
import time
import os

# === CONFIGURACIÓN ===
FRAMES_POR_SECUENCIA = 30
NUM_LANDMARKS = 20
DIMENSIONES = NUM_LANDMARKS * 3  # 60 características por frame

# Inicializar MediaPipe Hands
mp_hands = mp.solutions.hands
hands = mp_hands.Hands(max_num_hands=1, min_detection_confidence=0.7)
mp_drawing = mp.solutions.drawing_utils

# Crear carpetas
os.makedirs("secuencias_guardadas", exist_ok=True)
os.makedirs("landmarks_estaticos", exist_ok=True)

def capturar_landmarks(frame):
    frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    resultado = hands.process(frame_rgb)
    if resultado.multi_hand_landmarks:
        landmarks = resultado.multi_hand_landmarks[0].landmark
        puntos = []
        for lm in landmarks[:20]:
            puntos.extend([lm.x, lm.y, lm.z])
        return puntos, resultado.multi_hand_landmarks[0]
    else:
        return None, None

def capturar_estatico(etiqueta, cantidad):
    cap = cv2.VideoCapture(0)
    capturados = 0
    print(f"\n📸 Capturando {cantidad} vectores estáticos para '{etiqueta}'. Presiona 'c' para guardar cada uno.")

    while capturados < cantidad:
        ret, frame = cap.read()
        if not ret:
            continue

        landmarks, hand_landmarks = capturar_landmarks(frame)

        if landmarks is not None:
            cv2.putText(frame, f'Mano detectada | Capturados: {capturados}/{cantidad}', (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0,255,0), 2)
            mp_drawing.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)
        else:
            cv2.putText(frame, 'Mano no detectada', (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0,0,255), 2)

        cv2.imshow("Captura Estática", frame)
        key = cv2.waitKey(1) & 0xFF

        if key == ord('c') and landmarks is not None:
            timestamp = int(time.time())
            nombre_archivo = f"{etiqueta.upper()}_estatico_{timestamp}.npy"
            np.save(os.path.join("landmarks_estaticos", nombre_archivo), np.array(landmarks))
            capturados += 1
            print(f"✅ Vector estático guardado en '{nombre_archivo}'")
            time.sleep(1)

        elif key == 27:
            break

    cap.release()
    cv2.destroyAllWindows()
    print(f"✅ Captura estática de '{etiqueta}' completada con {capturados} ejemplos.\n")

def capturar_dinamico(etiqueta, cantidad):
    cap = cv2.VideoCapture(0)
    capturados = 0
    print(f"\n🎬 Capturando {cantidad} secuencias dinámicas para '{etiqueta}'.\n")

    while capturados < cantidad:
        secuencia = []
        print(f"📽️ Capturando secuencia {capturados + 1}/{cantidad}. Posiciónate en 3 segundos...")
        time.sleep(3)

        cancelar = False  # bandera para saber si el usuario canceló con ESC

        while len(secuencia) < FRAMES_POR_SECUENCIA:
            ret, frame = cap.read()
            if not ret:
                continue

            landmarks, hand_landmarks = capturar_landmarks(frame)

            if landmarks is not None:
                secuencia.append(np.array(landmarks))
                cv2.putText(frame, f'Frame: {len(secuencia)}/{FRAMES_POR_SECUENCIA}', (10, 30),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0,255,0), 2)
                mp_drawing.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)
            else:
                cv2.putText(frame, 'Mano no detectada', (10, 30),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0,0,255), 2)

            cv2.imshow("Captura Dinámica", frame)
            if cv2.waitKey(1) & 0xFF == 27:
                print("❌ Secuencia cancelada por el usuario con ESC.")
                cancelar = True
                break

        if cancelar:
            print("🚪 Saliendo de la captura dinámica por ESC.")
            break  # salimos del bucle de capturados

        if len(secuencia) == FRAMES_POR_SECUENCIA:
            secuencia = np.array(secuencia)
            timestamp = int(time.time())
            nombre_archivo = f"{etiqueta.upper()}_secuencia_{timestamp}.npy"
            np.save(os.path.join("secuencias_guardadas", nombre_archivo), secuencia)
            print(f"✅ Secuencia dinámica guardada en '{nombre_archivo}' con shape {secuencia.shape}")
            capturados += 1
            time.sleep(1)
        else:
            print("❌ La secuencia fue incompleta y no se guardó.")

    cap.release()
    cv2.destroyAllWindows()
    print(f"✅ Captura dinámica finalizada con {capturados} ejemplos guardados.\n")

# ==== USO GENERAL ====
# ==== USO GENERAL ====
if __name__ == "__main__":
    while True:
        modo = input("👉 ¿Deseas capturar 'estatico' o 'dinamico'? (o 'salir' para terminar): ").strip().lower()
        if modo == 'salir':
            print("👋 Finalizando captura.")
            break
        elif modo in ['estatico', 'dinamico']:
            etiqueta = input("👉 Ingresa la etiqueta para esta captura: ").strip().upper()
            print(f"👉 Usando etiqueta: '{etiqueta}'")


            cantidad = int(input(f"👉 ¿Cuántos ejemplos deseas capturar para '{etiqueta}'?: "))

            if modo == 'estatico':
                capturar_estatico(etiqueta, cantidad)
            else:
                capturar_dinamico(etiqueta, cantidad)
        else:
            print("❌ Opción inválida. Escribe 'estatico', 'dinamico' o 'salir'.")
