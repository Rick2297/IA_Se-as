import os
import glob
from collections import Counter

CARPETA_ESTATICOS = 'landmarks_estaticos'
CARPETA_DINAMICOS = 'secuencias_guardadas'

def contar_en_carpeta(carpeta):
    archivos = glob.glob(os.path.join(carpeta, "*.npy"))
    etiquetas = [os.path.basename(f).split('_')[0].upper() for f in archivos]
    return Counter(etiquetas), archivos

# Contamos y listamos archivos
conteo_estaticos, archivos_estaticos = contar_en_carpeta(CARPETA_ESTATICOS)
conteo_dinamicos, archivos_dinamicos = contar_en_carpeta(CARPETA_DINAMICOS)

# Unificamos etiquetas
todas_etiquetas = set(conteo_estaticos.keys()) | set(conteo_dinamicos.keys())

print("\n✅ Conteo combinado de archivos por etiqueta:\n")
print(f"{'Etiqueta':<10} {'Estáticos':<10} {'Dinámicos':<10} {'Total':<10}")
print("-" * 40)

for etiqueta in sorted(todas_etiquetas):
    num_estaticos = conteo_estaticos.get(etiqueta, 0)
    num_dinamicos = conteo_dinamicos.get(etiqueta, 0)
    total = num_estaticos + num_dinamicos
    print(f"{etiqueta:<10} {num_estaticos:<10} {num_dinamicos:<10} {total:<10}")

print("\n✅ Conteo completo finalizado.\n")

# --- Opcional: borrar archivos ---
opcion = input("❓ ¿Quieres eliminar archivos? (si/no): ").strip().lower()
if opcion == 'si':
    tipo = input("👉 ¿Qué deseas borrar? ('estatico', 'dinamico'): ").strip().lower()
    etiqueta_borrar = input("👉 Escribe la etiqueta que quieres borrar (ej. 'C'): ").strip().upper()

    if tipo == 'estatico':
        archivos_a_borrar = [f for f in archivos_estaticos if os.path.basename(f).startswith(etiqueta_borrar + '_')]
    elif tipo == 'dinamico':
        archivos_a_borrar = [f for f in archivos_dinamicos if os.path.basename(f).startswith(etiqueta_borrar + '_')]
    else:
        archivos_a_borrar = []
        print("❌ Tipo inválido.")

    if archivos_a_borrar:
        for f in archivos_a_borrar:
            os.remove(f)
            print(f"🗑️ Archivo eliminado: {f}")
        print(f"✅ Se eliminaron {len(archivos_a_borrar)} archivos {tipo} de la etiqueta '{etiqueta_borrar}'.")
    else:
        print(f"⚠️ No se encontraron archivos {tipo} para la etiqueta '{etiqueta_borrar}'.")

else:
    print("👌 No se eliminaron archivos.")
