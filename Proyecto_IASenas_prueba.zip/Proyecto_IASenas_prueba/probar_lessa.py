import cv2
import mediapipe as mp
import numpy as np
from tensorflow.keras.models import load_model
import tkinter as tk
from tkinter import messagebox

FRAMES_POR_SECUENCIA = 30
NUM_LANDMARKS = 20
DIMENSIONES = NUM_LANDMARKS * 3

# Cargar modelos
modelo_dinamico = load_model("lessa_modelo.h5")
modelo_estatico = load_model("modelo_landmarks.h5")

# Cargar etiquetas respectivas
etiquetas_estatico = np.load("lessa_etiquetas.npy", allow_pickle=True)
etiquetas_dinamico = np.load("etiquetas_dinamico.npy", allow_pickle=True)

mp_hands = mp.solutions.hands
hands = mp_hands.Hands(static_image_mode=False, max_num_hands=1, min_detection_confidence=0.7)
mp_drawing = mp.solutions.drawing_utils

def iniciar_camara(modo):
    cap = cv2.VideoCapture(0)
    secuencia = []
    prediccion_actual = ""

    messagebox.showinfo("Cámara", f"🎥 Modo: {modo.capitalize()} - Presiona 'q' para salir.")

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        result = hands.process(frame_rgb)

        if result.multi_hand_landmarks:
            for hand_landmarks in result.multi_hand_landmarks:
                mp_drawing.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)

                landmarks = []
                for lm in hand_landmarks.landmark[:NUM_LANDMARKS]:
                    landmarks.extend([lm.x, lm.y, lm.z])

                if modo == 'letra':
                    if len(landmarks) == DIMENSIONES:
                        input_estatico = np.array([landmarks], dtype=np.float32)
                        pred = modelo_estatico.predict(input_estatico, verbose=0)
                        idx = np.argmax(pred)
                        etiqueta = etiquetas_estatico[idx]
                        prediccion_actual = etiqueta
                    else:
                        prediccion_actual = "Datos insuficientes"

                elif modo == 'palabra':
                    secuencia.append(landmarks)
                    if len(secuencia) == FRAMES_POR_SECUENCIA:
                        input_dinamico = np.array([secuencia], dtype=np.float32)
                        pred = modelo_dinamico.predict(input_dinamico, verbose=0)
                        idx = np.argmax(pred)
                        if idx < len(etiquetas_dinamico):
                            conf = pred[0][idx]
                            etiqueta = etiquetas_dinamico[idx]
                            prediccion_actual = f"(D) {etiqueta} ({conf*100:.1f}%)"
                        else:
                            prediccion_actual = "(D) Clase desconocida"
                        secuencia = []
        else:
            secuencia = []

        cv2.putText(frame, f"Prediccion: {prediccion_actual}", (10,50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0,255,0), 2)
        cv2.imshow("Reconocimiento en LSA", frame)
        
        key = cv2.waitKey(1) & 0xFF
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
        elif key == ord('l'):  # tecla L para limpiar la predicción
           prediccion_actual = ""

    cap.release()
    cv2.destroyAllWindows()

# --- Interfaz gráfica
root = tk.Tk()
root.title("Reconocimiento de Lenguaje de Señas")
root.geometry("400x250")

label = tk.Label(root, text="Selecciona qué deseas traducir:", font=("Arial", 14))
label.pack(pady=20)

btn_letra = tk.Button(root, text="Traducir Letra (Estático)", command=lambda: iniciar_camara('letra'), font=("Arial", 12))
btn_letra.pack(pady=10)

btn_palabra = tk.Button(root, text="Traducir Palabra (Dinámico)", command=lambda: iniciar_camara('palabra'), font=("Arial", 12))
btn_palabra.pack(pady=10)

btn_salir = tk.Button(root, text="Salir", command=root.destroy, font=("Arial", 12))
btn_salir.pack(pady=10)

root.mainloop()
