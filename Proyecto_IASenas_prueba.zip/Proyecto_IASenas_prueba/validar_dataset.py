import os
import numpy as np

CARPETA_SECUENCIAS = 'secuencias_guardadas'
FRAMES_POR_SECUENCIA = 30
DIMENSIONES = 60  # 20 landmarks * 3 coordenadas

def validar_dataset():
    archivos = os.listdir(CARPETA_SECUENCIAS)
    print(f"🔍 Validando {len(archivos)} archivos en '{CARPETA_SECUENCIAS}':\n")

    archivos_invalidos = 0

    for archivo in archivos:
        path = os.path.join(CARPETA_SECUENCIAS, archivo)
        try:
            data = np.load(path)
            if data.shape != (FRAMES_POR_SECUENCIA, DIMENSIONES):
                print(f"[❌] {archivo} - shape {data.shape} (esperado {(FRAMES_POR_SECUENCIA, DIMENSIONES)})")
                archivos_invalidos += 1
            else:
                print(f"[✅] {archivo} - shape correcto: {data.shape}")
        except Exception as e:
            print(f"[⚠️] Error al leer {archivo}: {e}")
            archivos_invalidos += 1

    print(f"\n🔎 Resultado: {len(archivos) - archivos_invalidos} válidos | {archivos_invalidos} inválidos.")

if __name__ == "__main__":
    validar_dataset()
