import numpy as np
import glob
import os
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Input, Dropout, BatchNormalization
from tensorflow.keras.utils import to_categorical

# === CONFIGURACIÓN ===
NUM_LANDMARKS = 20
DIMENSIONES = NUM_LANDMARKS * 3  # 60 características por muestra
CARPETA_ESTATICOS = 'landmarks_estaticos'

X_estatico = []
y_estatico = []

# === CARGAR ARCHIVOS ESTÁTICOS ===
for file in glob.glob(os.path.join(CARPETA_ESTATICOS, "*.npy")):
    etiqueta = os.path.basename(file).split('_')[0].upper()
    vector = np.load(file, allow_pickle=True)

    if vector.shape[0] == DIMENSIONES:
        X_estatico.append(vector)
        y_estatico.append(etiqueta)
    else:
        print(f"[⚠️] Vector descartado por forma incorrecta: {vector.shape}")

X_estatico = np.array(X_estatico, dtype=np.float32)
y_estatico = np.array(y_estatico)

print(f"\n✅ Total ejemplos cargados: {len(X_estatico)}")
print(f"✅ Etiquetas únicas: {np.unique(y_estatico)}")

if len(X_estatico) == 0:
    print("❌ No hay datos válidos. Verifica la carpeta.")
    exit()

# === CODIFICAR ETIQUETAS A ONE-HOT ===
encoder = LabelEncoder()
y_encoded = encoder.fit_transform(y_estatico)
y_categorical = to_categorical(y_encoded)

# === DIVIDIR TRAIN Y TEST ===
X_train, X_test, y_train, y_test = train_test_split(X_estatico, y_categorical, test_size=0.2, random_state=42)

# === MODELO ESTÁTICO MEJORADO ===
modelo_estatico = Sequential([
    Input(shape=(DIMENSIONES,)),

    Dense(256, activation='relu'),
    BatchNormalization(),
    Dropout(0.3),

    Dense(128, activation='relu'),
    BatchNormalization(),
    Dropout(0.3),

    Dense(64, activation='relu'),
    Dropout(0.2),

    Dense(len(encoder.classes_), activation='softmax')
])

modelo_estatico.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])

# === ENTRENAMIENTO ===
modelo_estatico.fit(X_train, y_train, epochs=30, batch_size=16, validation_data=(X_test, y_test))

# === GUARDAR MODELO Y ETIQUETAS ===
modelo_estatico.save("modelo_landmarks.h5")
np.save("lessa_etiquetas.npy", encoder.classes_)

print("\n✅ Entrenamiento completado y modelo MEJORADO guardado como 'modelo_landmarks.h5'")
print("✅ Etiquetas guardadas en 'lessa_etiquetas.npy'")
