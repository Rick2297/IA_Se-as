import numpy as np
import glob
import os
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Masking, Input
from tensorflow.keras.utils import to_categorical

# === CONFIGURACIÓN ===
FRAMES_POR_SECUENCIA = 30
NUM_LANDMARKS = 20
DIMENSIONES = NUM_LANDMARKS * 3  # 60 características por frame
CARPETA_DINAMICOS = 'secuencias_guardadas'

X_dinamico = []
y_dinamico = []

# === CARGAR ARCHIVOS DINÁMICOS ===
for file in glob.glob(os.path.join(CARPETA_DINAMICOS, "*.npy")):
    etiqueta = os.path.basename(file).split('_')[0].upper()
    secuencia = np.load(file, allow_pickle=True)

    if secuencia.shape == (FRAMES_POR_SECUENCIA, DIMENSIONES):
        X_dinamico.append(secuencia)
        y_dinamico.append(etiqueta)
    else:
        print(f"[⚠️] Secuencia descartada por forma incorrecta: {secuencia.shape}")

X_dinamico = np.array(X_dinamico, dtype=np.float32)
y_dinamico = np.array(y_dinamico)

print(f"\n✅ Total ejemplos DINÁMICOS: {len(X_dinamico)}")
print(f"✅ Etiquetas únicas: {np.unique(y_dinamico)}")

if len(X_dinamico) == 0:
    print("❌ No hay datos válidos en dinámico. Verifica la carpeta.")
    exit()

# === CODIFICAR ETIQUETAS A ONE-HOT ===
encoder = LabelEncoder()
y_encoded_dinamico = encoder.fit_transform(y_dinamico)
y_cat_dinamico = to_categorical(y_encoded_dinamico)

# === DIVIDIR TRAIN Y TEST ===
X_train, X_test, y_train, y_test = train_test_split(X_dinamico, y_cat_dinamico, test_size=0.2, random_state=42)

# === MODELO DINÁMICO (LSTM) ===
modelo_dinamico = Sequential([
    Input(shape=(FRAMES_POR_SECUENCIA, DIMENSIONES)),
    Masking(mask_value=0.0),
    LSTM(128, return_sequences=True),
    LSTM(64),
    Dense(64, activation='relu'),
    Dense(len(encoder.classes_), activation='softmax')
])

modelo_dinamico.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])

# === ENTRENAMIENTO ===
modelo_dinamico.fit(X_train, y_train, epochs=20, batch_size=16, validation_data=(X_test, y_test))

# === GUARDAR MODELO Y ETIQUETAS ===
modelo_dinamico.save("lessa_modelo.h5")
np.save("etiquetas_dinamico.npy", encoder.classes_)  # CAMBIADO A etiquetas_dinamico.npy

print("\n✅ Entrenamiento completado y modelo DINÁMICO guardado como 'lessa_modelo.h5'")
print("✅ Etiquetas guardadas en 'etiquetas_dinamico.npy'")
